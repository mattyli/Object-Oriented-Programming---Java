Notes for my this project submission

Things can be optimized better:

1. I should have used an array list which would have dynamic size, but per the assignment instructions I had to use a static array.

I take full credit for the Entity.java, GuessMaster.java program whilst, the Date.java file was primarily written by ELEC 279 course staff with modification by me.


MLi 2022-02-09
