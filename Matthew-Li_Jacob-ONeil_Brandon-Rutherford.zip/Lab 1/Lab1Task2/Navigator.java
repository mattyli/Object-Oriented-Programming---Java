public class Navigator {
    public static void main(String[] args) {
        System.out.println("The Navigator is now the Driver");
    }
    
}
