// Lab 1 Task 1 by Matthew Li 
// Winter 2022 

public class HelloWorld {
    public static void main(String[] args) {
        System.out.print("Hello my friends in ELEC 279");
    }
}
